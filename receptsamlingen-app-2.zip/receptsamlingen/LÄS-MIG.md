# Receptsamlingen som app på Android

Alla filer i den här mappen ska ligga tillsammans på en webbadress. Appen i sig har ingen server och skickar ingenting någonstans. Recepten sparas bara i telefonens webbläsare.

## Lägg upp på GitHub Pages (gratis)

1. Skapa ett konto på github.com om du inte har ett.
2. Skapa ett nytt arkiv (New repository). Namn: `receptsamlingen`. Välj Public och skapa.
3. Välj "uploading an existing file" och ladda upp ALLA filer från mappen: index.html, manifest.webmanifest, sw.js, icon-192.png, icon-512.png, icon-maskable-512.png och apple-touch-icon.png. Tryck Commit changes.
4. Gå till Settings, sedan Pages. Under Source väljer du "Deploy from a branch", gren `main` och mapp `/ (root)`. Spara.
5. Efter någon minut visas adressen högst upp på Pages-sidan: `https://DITTNAMN.github.io/receptsamlingen/`

Arkivet är publikt, men det innehåller bara själva appen. Dina recept ligger inte där.

## Installera på Android

1. Öppna adressen i Chrome på telefonen.
2. Tryck på menyn (tre punkter) och välj "Installera app" eller "Lägg till på startskärmen".
3. Starta appen från ikonen på hemskärmen.

## Flytta dina recept

- I appen: tryck på ⋯ uppe till höger, Säkerhetskopia, Exportera. Filen innehåller recept, kokböcker, taggar och foton.
- På nya telefonen: installera appen, öppna ⋯, Säkerhetskopia, Välj säkerhetskopia.
- Spara filen i Google Drive eller skicka den till dig själv. Gör det regelbundet. En gul prick på ⋯ visar när det har gått över 30 dagar.

## Uppdatera appen senare

Ladda upp den nya index.html och sw.js på samma ställe i GitHub (Add file, Upload files, ersätt). Appen hämtar den nya versionen nästa gång du öppnar den med nätet på.
